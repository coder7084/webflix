$(document).ready(function() {  
 $('input[name=id]').val('124679');  
 //$('input[name=id]').attr('disabled', 'disabled');
 
 
 

}); //end of doc.ready

$('#submitbutton').click( function(){
   //$('input[name=id]').removeClass('disabled');
 });